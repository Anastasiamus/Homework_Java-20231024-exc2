import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println(" Введите натуральное число для вычисления факториала: ");
        int n = factorial(scr.nextInt());
        System.out.println(" Факториал равен: " + n);
    }

    private static int factorial(int n) {
        int result = 1;
        if (n == 0) {
            return result;
        } else {
            for (int i = 1; i <= n ; i++) {
                result= result*i;
            }
            return result;
        }
    }
}
//Задание 2.
//Используя рекурсию, написать метод вычисления факториала числа n (n!), вводимого с клавиатуры.